const crypto = require("crypto");

module.exports = (req, res, next) => {
    if (req.session && !req.session.csrfToken) {
        req.session.csrfToken = crypto.randomBytes(32).toString('hex');
    };
    
    res.locals.csrfToken = req.session ? req.session.csrfToken : '';
    const safeMethods = ['GET', 'HEAD', 'OPTIONS'];
    if (safeMethods.includes(req.method)) {
        return next();
    };

    const bypassPaths = ['/webhooks', '/admission/'];
    if (bypassPaths.some(p => req.path.startsWith(p))) {
        return next();
    };

    const isAuthenticated = req.session?.user || req.user || req.cookies?.token;
    if (isAuthenticated) {
        const token = req.body?._csrf || req.headers['x-csrf-token'] || req.headers['x-xsrf-token'] || req.query?._csrf;
        if (!token || token !== req.session?.csrfToken) {
            console.warn(`[CSRF] Blocked potential CSRF attack on ${req.method} ${req.path}`);
            const err = new Error("Security verification failed (CSRF token invalid or expired). Please go back, refresh, and try again.");
            err.status = 403;
            return next(err);
        };
    };
    next();
};
