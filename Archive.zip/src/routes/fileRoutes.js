const express = require("express");
const router = express.Router();
const path = require("path");
const fs = require("fs");
const { verifyToken } = require("../middleware/auth");

router.get("/uploads/*", verifyToken, (req, res) => {
    const rawParam = req.params[0] || "";

    if (rawParam.includes("..") || rawParam.includes("\0")) {
        return res.status(400).json({ success: false, message: "Invalid file path." });
    };

    const storageRoot = path.resolve(path.join(__dirname, "../../storage/uploads"));
    const resolvedFile = path.resolve(path.join(storageRoot, rawParam));

    if (!resolvedFile.startsWith(storageRoot + path.sep) && resolvedFile !== storageRoot) {
        return res.status(400).json({ success: false, message: "Invalid file path." });
    };

    if (!fs.existsSync(resolvedFile)) {
        return res.status(404).json({ success: false, message: "File not found." });
    };

    return res.sendFile(resolvedFile);
});

module.exports = router;