const multer = require('multer');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const fastCsv = require('fast-csv');
const db = require('../../config/database');
const { getRedisClient } = require('../../config/redis');
const { parseFile } = require('../../utils/csvParser');
const { loadValidationCache, validateRow, resolveClassId } = require('../../utils/validators/importValidators');
const importLogModel = require('../../models/importLogModel');
const { FileValidationError } = require('../../utils/errors');
const { calculateGrade, isPassed } = require('../../utils/marksHelper');
const { isFileUploadEnabled, fileUploadGuard } = require('../../middleware/fileUploadGuard');

const uploadDir = path.resolve(__dirname, '../../../storage/uploads/imports');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
};

const errorReportsDir = path.resolve(__dirname, '../../../storage/uploads/error-reports');
if (!fs.existsSync(errorReportsDir)) {
    fs.mkdirSync(errorReportsDir, { recursive: true });
};

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    if (!isFileUploadEnabled()) {
        const err = new FileValidationError('File uploads are currently disabled.');
        err.status = 403;
        err.statusCode = 403;
        err.code = "FILE_UPLOADS_DISABLED";
        return cb(err, false);
    };
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext === '.csv' || ext === '.xlsx') {
        cb(null, true);
    } else {
        cb(new FileValidationError('Only .csv and .xlsx files are allowed!'), false);
    };
};

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: fileFilter
}).single('file');

const memoryProgressCache = new Map();
async function setJobProgress(jobId, data) {
    const redis = getRedisClient();
    if (redis) {
        await redis.set(`import_job:${jobId}`, JSON.stringify(data), { EX: 3600 });
    } else {
        memoryProgressCache.set(jobId, data);
    };
};

async function getJobProgress(jobId) {
    const redis = getRedisClient();
    if (redis) {
        const val = await redis.get(`import_job:${jobId}`);
        return val ? JSON.parse(val) : null;
    } else {
        return memoryProgressCache.get(jobId) || null;
    };
};

function writeErrorReport(errors) {
    return new Promise((resolve, reject) => {
        const reportFilename = `import_errors_${Date.now()}.csv`;
        const reportPath = path.join(errorReportsDir, reportFilename);
        const ws = fs.createWriteStream(reportPath);
        const csvStream = fastCsv.format({ headers: true });
        csvStream.pipe(ws);

        errors.forEach(err => {
            csvStream.write({
                'Row Number': err.row_number,
                'Field': err.field,
                'Error Message': err.message,
                'Submitted Value': err.value
            });
        });

        csvStream.end();
        ws.on('finish', () => {
            resolve(`/uploads/error-reports/${reportFilename}`);
        });
        ws.on('error', (err) => {
            reject(err);
        });
    });
};

async function checkRateLimit(userId, schoolId) {
    const rows = await db.queryAsync(
        `SELECT COUNT(*) as count 
        FROM import_logs 
        WHERE imported_by = ? AND school_id = ? 
            AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)`,
        [userId, schoolId]
    );
    return rows[0].count < 5;
};

exports.renderImportDashboard = async (req, res, next) => {
    try {
        const schoolId = (req.user?.school_id || req.session.user?.school_id);
        const logs = await importLogModel.getLogsBySchool(schoolId);
        res.render('schoolAdmin/imports/dashboard', {
            title: 'Bulk Imports',
            logs,
            user: req.user || req.session.user
        });
    } catch (err) {
        next(err);
    };
};

exports.getLogs = async (req, res, next) => {
    try {
        const schoolId = (req.user?.school_id || req.session.user?.school_id);
        const logs = await importLogModel.getLogsBySchool(schoolId);
        return res.status(200).json({ success: true, logs });
    } catch (err) {
        next(err);
    };
};

exports.getJobStatus = async (req, res, next) => {
    try {
        const { jobId } = req.params;
        const progress = await getJobProgress(jobId);
        if (!progress) {
            return res.status(404).json({ success: false, message: 'Job status not found' });
        };
        return res.status(200).json({ success: true, ...progress });
    } catch (err) {
        next(err);
    };
};

exports.importEntity = (req, res, next) => {
    if (!isFileUploadEnabled()) {
        return res.status(403).json({ success: false, message: 'File uploads are currently disabled.' });
    };
    upload(req, res, async (err) => {
        if (err) {
            if (err.code === 'FILE_UPLOADS_DISABLED' || err.status === 403 || err.statusCode === 403) {
                return res.status(403).json({ success: false, message: 'File uploads are currently disabled.' });
            };
            return res.status(400).json({ success: false, message: 'File upload failed' });
        };

        if (!req.file) {
            return res.status(400).json({ success: false, message: 'Please upload a file' });
        };

        const schoolId = (req.user?.school_id || req.session.user?.school_id);
        const userId = (req.user?.id || req.session.user?.id);
        const userRole = (req.user?.role || req.session.user?.role);
        const { entityType } = req.params;
        const importMode = req.body.import_mode || req.query.import_mode;

        try {
            const withinLimit = await checkRateLimit(userId, schoolId);
            if (!withinLimit) {
                fs.unlinkSync(req.file.path);
                return res.status(429).json({
                    success: false,
                    message: 'Rate limit exceeded: You can only perform 5 imports per hour.'
                });
            };

            const rows = await parseFile(req.file.path);
            if (rows.length === 0) {
                fs.unlinkSync(req.file.path);
                return res.status(400).json({ success: false, message: 'Uploaded file is empty' });
            };

            const sampleRow = rows[0];
            const requiredHeadersMap = {
                students: ['name', 'email'],
                teachers: ['name', 'email'],
                books: ['title'],
                fees: ['class_id', 'fee_type', 'amount'],
                marks: ['exam_id', 'student_id', 'subject_id', 'marks_obtained'],
                parents: ['student_admission_no'],
                classes_sections: ['class_name', 'section'],
                subjects: ['subject_name'],
                student_class_allocation: ['student_admission_no', 'class_name', 'section'],
                teacher_subject_assignment: ['teacher_email', 'subject_name', 'class_name', 'section'],
                timetable: ['class_name', 'section', 'day', 'period_number', 'subject_name', 'teacher_email']
            };

            const required = requiredHeadersMap[entityType];
            if (!required) {
                fs.unlinkSync(req.file.path);
                return res.status(400).json({ success: false, message: `Invalid entity type: ${entityType}` });
            };

            const missingHeaders = required.filter(h => sampleRow[h] === undefined);
            if (missingHeaders.length > 0) {
                fs.unlinkSync(req.file.path);
                return res.status(400).json({
                    success: false,
                    message: `Invalid template: missing required columns (${missingHeaders.join(', ')})`
                });
            };

            const jobId = 'job_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
            const relativeFilePath = `/uploads/imports/${req.file.filename}`;
            if (rows.length > 500) {
                processImportAsync(jobId, entityType, rows, schoolId, userId, userRole, req.file.filename, relativeFilePath, req.file.path, importMode);
                return res.status(202).json({
                    success: true,
                    message: 'Import file is large and has been queued for background processing.',
                    jobId,
                    total_rows: rows.length
                });
            } else {
                const result = await processImport(jobId, entityType, rows, schoolId, userId, userRole, req.file.filename, relativeFilePath, req.file.path, importMode);
                return res.status(result.success ? 200 : 400).json(result);
            };
        } catch (error) {
            if (fs.existsSync(req.file.path)) {
                fs.unlinkSync(req.file.path);
            }
            return res.status(error.statusCode || 500).json({
                success: false,
                message: 'Import failed due to server error'
            });
        };
    });
};

async function processImportAsync(jobId, entityType, rows, schoolId, userId, userRole, filename, relativeFilePath, fullFilePath, importMode) {
    try {
        await setJobProgress(jobId, { 
            status: 'processing', progress: 0, current_row: 0, total_rows: rows.length 
        });
        const result = await processImport(jobId, entityType, rows, schoolId, userId, userRole, filename, relativeFilePath, fullFilePath, importMode, async (current, total) => {
            const pct = Math.round((current / total) * 100);
            await setJobProgress(jobId, { status: 'processing', progress: pct, current_row: current, total_rows: total });
        });
        await setJobProgress(jobId, { status: result.success ? 'completed' : 'failed', progress: 100, current_row: rows.length, total_rows: rows.length, result });
    } catch (err) {
        await setJobProgress(jobId, { 
            status: 'failed', progress: 100, message: 'Import job failed due to server error' 
        });
    };
};

async function processImport(jobId, entityType, rows, schoolId, userId, userRole, filename, relativeFilePath, fullFilePath, importMode, progressCallback = null) {
    const cache = await loadValidationCache(schoolId);
    const fileContext = {
        emails: new Map(),
        rollNumbers: new Map()
    };

    const errors = [];
    const validRows = [];

    for (let i = 0; i < rows.length; i++) {
        const rowErrors = validateRow(entityType, rows[i], i + 1, cache, fileContext);
        if (rowErrors.length > 0) {
            errors.push(...rowErrors);
        } else {
            validRows.push({ data: rows[i], index: i + 1 });
        };

        if (progressCallback && (i + 1) % 50 === 0) {
            await progressCallback(i + 1, rows.length);
        };
    };

    if (progressCallback) {
        await progressCallback(rows.length, rows.length);
    };

    let errorReportUrl = null;
    if (errors.length > 0) {
        errorReportUrl = await writeErrorReport(errors);
    };

    if (importMode === 'all_or_nothing' && errors.length > 0) {
        await importLogModel.createLog({
            school_id: schoolId,
            imported_by: userId,
            user_role: userRole,
            entity_type: entityType,
            file_name: filename,
            file_path: relativeFilePath,
            total_rows: rows.length,
            success_count: 0,
            failed_count: rows.length,
            error_report_path: errorReportUrl,
            status: 'failed'
        });

        if (fs.existsSync(fullFilePath)) fs.unlinkSync(fullFilePath);
        return {
            success: false,
            message: 'Import rejected: One or more rows failed validation. See error report.',
            error_code: 'ROW_VALIDATION_FAILED',
            details: errors[0],
            errors,
            error_report_url: errorReportUrl
        };
    };

    if (validRows.length === 0) {
        await importLogModel.createLog({
            school_id: schoolId,
            imported_by: userId,
            user_role: userRole,
            entity_type: entityType,
            file_name: filename,
            file_path: relativeFilePath,
            total_rows: rows.length,
            success_count: 0,
            failed_count: rows.length,
            error_report_path: errorReportUrl,
            status: 'failed'
        });
        if (fs.existsSync(fullFilePath)) fs.unlinkSync(fullFilePath);
        return {
            success: false,
            message: 'All rows in the spreadsheet failed validation.',
            errors,
            error_report_url: errorReportUrl
        };
    };

    let successCount = 0;
    try {
        await db.withTransaction(async (tx) => {
            const affectedClasses = new Set();
            for (const item of validRows) {
                const row = item.data;

                if (entityType === 'students') {
                    const finalClassId = resolveClassId(cache, row.class_id, row.section_id || row.section || row.section_name, row.medium || 'English');

                    let className = null;
                    if (finalClassId) {
                        const cls = await tx.query('SELECT class_name FROM classes WHERE id = ? LIMIT 1', [finalClassId]);
                        if (cls.length > 0) className = cls[0].class_name;
                    } else if (row.class_id) {
                        className = String(row.class_id).trim();
                    };
                    if (className) {
                        affectedClasses.add(className);
                    };

                    const nameParts = row.name.trim().split(/\s+/);
                    const first_name = nameParts[0];
                    const last_name = nameParts.slice(1).join(' ') || '';
                    const existingUserRows = await tx.query(
                        "SELECT id FROM users WHERE email = ? AND school_id = ? AND deleted_at IS NULL LIMIT 1",
                        [row.email, schoolId]
                    );
                    const existingUser = existingUserRows[0];

                    let studentId;
                    let uId;
                    if (existingUser) {
                        uId = existingUser.id;
                        await tx.query(
                            "UPDATE users SET first_name = ?, last_name = ? WHERE id = ?",
                            [first_name, last_name, uId]
                        );

                        const existingStudentRows = await tx.query(
                            "SELECT id FROM students WHERE user_id = ? AND school_id = ? AND deleted_at IS NULL LIMIT 1",
                            [uId, schoolId]
                        );
                        const existingStudent = existingStudentRows[0];

                        if (existingStudent) {
                            studentId = existingStudent.id;
                            await tx.query(
                                `UPDATE students SET class_id = ?, roll_no = ?, dob = ?, gender = ?, admission_date = ?
                                WHERE id = ?`,
                                [
                                    finalClassId,
                                    row.roll_no || null,
                                    row.date_of_birth || row.dob || null,
                                    row.gender || null,
                                    row.admission_date || new Date().toISOString().split('T')[0],
                                    studentId
                                ]
                            );
                        } else {
                            const studentResult = await tx.query(
                                `INSERT INTO students (school_id, user_id, class_id, admission_no, roll_no, dob, gender, admission_date, status)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
                                [
                                    schoolId, uId, finalClassId,
                                    'ADM' + Date.now() + Math.floor(Math.random() * 100),
                                    row.roll_no || null,
                                    row.date_of_birth || row.dob || null,
                                    row.gender || null,
                                    row.admission_date || new Date().toISOString().split('T')[0]
                                ]
                            );
                            studentId = studentResult.insertId;
                        };
                    } else {
                        const hashedPassword = await bcrypt.hash('SchoolSync@123', 10);
                        const userResult = await tx.query(
                            `INSERT INTO users (school_id, first_name, last_name, email, password, role, status, is_default_password)
                            VALUES (?, ?, ?, ?, ?, 'student', 'active', 1)`,
                            [schoolId, first_name, last_name, row.email, hashedPassword]
                        );
                        uId = userResult.insertId;

                        const lastStudents = await tx.query(
                            "SELECT admission_no FROM students WHERE admission_no LIKE 'ADM%' ORDER BY id DESC LIMIT 1"
                        );

                        let nextNum = 40026;
                        if (lastStudents.length > 0) {
                            const lastNumParsed = parseInt(lastStudents[0].admission_no.replace('ADM', ''), 10);
                            if (!isNaN(lastNumParsed)) nextNum = lastNumParsed + 1;
                        };
                        
                        const admissionNo = 'ADM' + String(nextNum).padStart(6, '0');
                        const studentResult = await tx.query(
                            `INSERT INTO students (school_id, user_id, class_id, admission_no, roll_no, dob, gender, admission_date, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
                            [
                                schoolId, uId, finalClassId, admissionNo,
                                row.roll_no || null,
                                row.date_of_birth || row.dob || null,
                                row.gender || null,
                                row.admission_date || new Date().toISOString().split('T')[0]
                            ]
                        );
                        studentId = studentResult.insertId;
                    };

                    const existingFamilyRows = await tx.query("SELECT id FROM student_family WHERE student_id = ? LIMIT 1", [studentId]);
                    const existingFamily = existingFamilyRows[0];
                    if (existingFamily) {
                        await tx.query(
                            "UPDATE student_family SET father_name = ?, father_phone = ? WHERE student_id = ?",
                            [row.parent_name || null, row.parent_phone || null, studentId]
                        );
                    } else {
                        await tx.query(
                            "INSERT INTO student_family (student_id, father_name, father_phone) VALUES (?, ?, ?)",
                            [studentId, row.parent_name || null, row.parent_phone || null]
                        );
                    };

                    const existingAddrRows = await tx.query("SELECT id FROM student_address_transport WHERE student_id = ? LIMIT 1", [studentId]);
                    const existingAddr = existingAddrRows[0];
                    if (existingAddr) {
                        await tx.query(
                            "UPDATE student_address_transport SET permanent_address = ?, current_address = ? WHERE student_id = ?",
                            [row.address || null, row.address || null, studentId]
                        );
                    } else {
                        await tx.query(
                            "INSERT INTO student_address_transport (student_id, permanent_address, current_address) VALUES (?, ?, ?)",
                            [studentId, row.address || null, row.address || null]
                        );
                    };
                }
                else if (entityType === 'teachers') {
                    const nameParts = row.name.trim().split(/\s+/);
                    const first_name = nameParts[0];
                    const last_name = nameParts.slice(1).join(' ') || '';

                    const existingUserRows = await tx.query(
                        "SELECT id FROM users WHERE email = ? AND school_id = ? AND deleted_at IS NULL LIMIT 1",
                        [row.email, schoolId]
                    );
                    const existingUser = existingUserRows[0];

                    let uId;
                    let teacherId;

                    if (existingUser) {
                        uId = existingUser.id;
                        await tx.query("UPDATE users SET first_name = ?, last_name = ?, phone = ? WHERE id = ?", [first_name, last_name, row.phone || null, uId]);

                        const existingTeacherRows = await tx.query("SELECT id FROM teachers WHERE user_id = ? AND school_id = ? LIMIT 1", [uId, schoolId]);
                        const existingTeacher = existingTeacherRows[0];
                        if (existingTeacher) {
                            teacherId = existingTeacher.id;
                            await tx.query(
                                `UPDATE teachers SET qualification = ?, joining_date = ?, subject = ? WHERE id = ?`,
                                [row.qualification || null, row.joining_date || null, row.subjects || null, teacherId]
                            );
                        } else {
                            const teacherResult = await tx.query(
                                `INSERT INTO teachers (school_id, user_id, subject, qualification, joining_date)
                                VALUES (?, ?, ?, ?, ?)`,
                                [schoolId, uId, row.subjects || null, row.qualification || null, row.joining_date || null]
                            );
                            teacherId = teacherResult.insertId;
                        }
                    } else {
                        const hashedPassword = await bcrypt.hash('SchoolSync@123', 10);
                        const userResult = await tx.query(
                            `INSERT INTO users (school_id, first_name, last_name, email, phone, password, role, status, is_default_password)
                            VALUES (?, ?, ?, ?, ?, ?, 'teacher', 'active', 1)`,
                            [schoolId, first_name, last_name, row.email, row.phone || null, hashedPassword]
                        );
                        uId = userResult.insertId;

                        const teacherResult = await tx.query(
                            `INSERT INTO teachers (school_id, user_id, subject, qualification, joining_date)
                            VALUES (?, ?, ?, ?, ?)`,
                            [schoolId, uId, row.subjects || null, row.qualification || null, row.joining_date || null]
                        );
                        teacherId = teacherResult.insertId;
                    }

                    if (row.salary) {
                        const salaryAmt = parseFloat(row.salary);
                        if (!isNaN(salaryAmt)) {
                            await tx.query(
                                `INSERT INTO salary_structures (school_id, user_id, role, amount)
                                VALUES (?, ?, 'teacher', ?)
                                ON DUPLICATE KEY UPDATE amount = VALUES(amount)`,
                                [schoolId, uId, salaryAmt]
                            );
                        }
                    };
                }
                else if (entityType === 'books') {
                    let existingBook = null;
                    if (row.isbn) {
                        const existingBookRows = await tx.query(
                            "SELECT id FROM library_books WHERE isbn = ? AND school_id = ? LIMIT 1",
                            [row.isbn, schoolId]
                        );
                        existingBook = existingBookRows[0];
                    }

                    const qty = parseInt(row.quantity || 1, 10);

                    if (existingBook) {
                        await tx.query(
                            `UPDATE library_books SET total_copies = total_copies + ?, available_copies = available_copies + ?, category_id = ?, rack_id = ?, publisher = ?, publish_year = ? 
                            WHERE id = ?`,
                            [qty, qty, row.category_id || null, row.rack_id || null, row.publisher || null, row.published_year || null, existingBook.id]
                        );
                    } else {
                        await tx.query(
                            `INSERT INTO library_books (school_id, category_id, rack_id, title, author, isbn, publisher, publish_year, total_copies, available_copies, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
                            [ schoolId, row.category_id || null, row.rack_id || null, row.title, row.author || null, row.isbn || null, row.publisher || null, row.published_year || null, qty, qty ]
                        );
                    };
                }
                else if (entityType === 'fees') {
                    const existingStructureRows = await tx.query(
                        "SELECT id FROM fee_structures WHERE school_id = ? AND class_id = ? AND fee_name = ? LIMIT 1",
                        [schoolId, Number(row.class_id), row.fee_type]
                    );
                    const existingStructure = existingStructureRows[0];

                    if (existingStructure) {
                        await tx.query(
                            `UPDATE fee_structures SET amount = ?, due_date = ?, fee_type = ? 
                            WHERE id = ?`,
                            [parseFloat(row.amount), row.due_date || null, row.fee_type, existingStructure.id]
                        );
                    } else {
                        await tx.query(
                            `INSERT INTO fee_structures (school_id, class_id, fee_name, amount, fee_type, due_date, frequency, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, 'monthly', NOW())`,
                            [schoolId, Number(row.class_id), row.fee_type, parseFloat(row.amount), row.fee_type, row.due_date || null]
                        );
                    };
                }
                else if (entityType === 'marks') {
                    const examRows = await tx.query(
                        "SELECT max_marks, pass_marks FROM exams WHERE id = ? AND school_id = ? LIMIT 1",
                        [Number(row.exam_id), schoolId]
                    );
                    const exam = examRows[0];
                    if (!exam) {
                        throw new Error(`Exam not found for exam_id ${row.exam_id}`);
                    }

                    const obtainedMarks = parseFloat(row.marks_obtained);
                    const gradeInfo = calculateGrade(obtainedMarks, exam.max_marks);
                    const status = isPassed(obtainedMarks, exam.pass_marks) ? 'pass' : 'fail';
                    const existingMarkRows = await tx.query(
                        "SELECT id FROM marks WHERE school_id = ? AND exam_id = ? AND student_id = ? AND subject_id = ? LIMIT 1",
                        [schoolId, Number(row.exam_id), Number(row.student_id), Number(row.subject_id)]
                    );
                    const existingMark = existingMarkRows[0];

                    if (existingMark) {
                        await tx.query(
                            `UPDATE marks SET obtained_marks = ?, grade = ?, grade_point = ?, status = ?, remarks = ? WHERE id = ?`,
                            [obtainedMarks, gradeInfo.grade, gradeInfo.gradePoint, status, row.remarks || null, existingMark.id]
                        );
                    } else {
                        await tx.query(
                            `INSERT INTO marks (school_id, exam_id, student_id, subject_id, total_marks, obtained_marks, grade, grade_point, status, remarks)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                            [ schoolId, Number(row.exam_id), Number(row.student_id), Number(row.subject_id), parseFloat(exam.max_marks), obtainedMarks, gradeInfo.grade, gradeInfo.gradePoint, status, row.remarks || null ]
                        );
                    };
                }
                else if (entityType === 'parents') {
                    const parentName = (row.parent_name || row.name || '').trim();
                    const studentAdmNo = (row.student_admission_no || row.student_id || '').toString().trim();
                    const relation = (row.relationship || row.relation || 'Father').trim();
                    const mobile = (row.mobile || row.phone || row.parent_phone || '').trim();
                    const email = (row.email || row.parent_email || '').trim();
                    const address = (row.address || '').trim();
                    const city = (row.city || '').trim();
                    const state = (row.state || '').trim();
                    const pincode = (row.pincode || '').trim();
                    const occupation = (row.occupation || '').trim();

                    const studentRows = await tx.query(
                        "SELECT id FROM students WHERE (LOWER(admission_no) = LOWER(?) OR id = ?) AND school_id = ? AND deleted_at IS NULL LIMIT 1",
                        [studentAdmNo, parseInt(studentAdmNo) || 0, schoolId]
                    );

                    if (studentRows.length > 0) {
                        const studentId = studentRows[0].id;
                        let parentUserId = null;

                        if (email) {
                            const existingParentUsers = await tx.query(
                                "SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND school_id = ? AND deleted_at IS NULL LIMIT 1",
                                [email.toLowerCase(), schoolId]
                            );
                            if (existingParentUsers.length > 0) {
                                parentUserId = existingParentUsers[0].id;
                            } else {
                                const hashedPassword = await bcrypt.hash('SchoolSync@123', 10);
                                const nameParts = parentName.split(/\s+/);
                                const firstName = nameParts[0] || 'Parent';
                                const lastName = nameParts.slice(1).join(' ') || '';
                                const userRes = await tx.query(
                                    `INSERT INTO users (school_id, first_name, last_name, email, phone, password, role, status, is_default_password)
                                     VALUES (?, ?, ?, ?, ?, ?, 'parent', 'active', 1)`,
                                    [schoolId, firstName, lastName, email, mobile || null, hashedPassword]
                                );
                                parentUserId = userRes.insertId;
                            }
                        }

                        const familyRows = await tx.query("SELECT id FROM student_family WHERE student_id = ? LIMIT 1", [studentId]);
                        const normRelation = relation.toLowerCase();

                        if (familyRows.length > 0) {
                            if (normRelation === 'mother') {
                                await tx.query(
                                    `UPDATE student_family SET mother_name = ?, mother_phone = ?, mother_email = ?, mother_occupation = ?, school_id = ?, parent_user_id = COALESCE(?, parent_user_id) WHERE student_id = ?`,
                                    [parentName, mobile || null, email || null, occupation || null, schoolId, parentUserId, studentId]
                                );
                            } else if (normRelation === 'guardian') {
                                await tx.query(
                                    `UPDATE student_family SET guardian_name = ?, guardian_phone = ?, guardian_email = ?, guardian_occupation = ?, guardian_relation = ?, school_id = ?, parent_user_id = COALESCE(?, parent_user_id) WHERE student_id = ?`,
                                    [parentName, mobile || null, email || null, occupation || null, relation, schoolId, parentUserId, studentId]
                                );
                            } else {
                                await tx.query(
                                    `UPDATE student_family SET father_name = ?, father_phone = ?, father_email = ?, father_occupation = ?, school_id = ?, parent_user_id = COALESCE(?, parent_user_id) WHERE student_id = ?`,
                                    [parentName, mobile || null, email || null, occupation || null, schoolId, parentUserId, studentId]
                                );
                            }
                        } else {
                            await tx.query(
                                `INSERT INTO student_family (student_id, father_name, father_phone, father_email, father_occupation, mother_name, mother_phone, mother_email, mother_occupation, guardian_name, guardian_phone, guardian_email, guardian_occupation, guardian_relation, school_id, parent_user_id)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                                [
                                    studentId,
                                    normRelation === 'mother' ? null : parentName,
                                    normRelation === 'mother' ? null : (mobile || null),
                                    normRelation === 'mother' ? null : (email || null),
                                    normRelation === 'mother' ? null : (occupation || null),
                                    normRelation === 'mother' ? parentName : null,
                                    normRelation === 'mother' ? (mobile || null) : null,
                                    normRelation === 'mother' ? (email || null) : null,
                                    normRelation === 'mother' ? (occupation || null) : null,
                                    normRelation === 'guardian' ? parentName : null,
                                    normRelation === 'guardian' ? (mobile || null) : null,
                                    normRelation === 'guardian' ? (email || null) : null,
                                    normRelation === 'guardian' ? (occupation || null) : null,
                                    normRelation === 'guardian' ? relation : null,
                                    schoolId,
                                    parentUserId
                                ]
                            );
                        }

                        if (address || city || state || pincode) {
                            const addrRows = await tx.query("SELECT id FROM student_address_transport WHERE student_id = ? LIMIT 1", [studentId]);
                            if (addrRows.length > 0) {
                                await tx.query(
                                    `UPDATE student_address_transport SET permanent_address = COALESCE(?, permanent_address), permanent_city = COALESCE(?, permanent_city), permanent_state = COALESCE(?, permanent_state), permanent_pincode = COALESCE(?, permanent_pincode) WHERE student_id = ?`,
                                    [address || null, city || null, state || null, pincode || null, studentId]
                                );
                            } else {
                                await tx.query(
                                    `INSERT INTO student_address_transport (student_id, permanent_address, permanent_city, permanent_state, permanent_pincode) VALUES (?, ?, ?, ?, ?)`,
                                    [studentId, address || null, city || null, state || null, pincode || null]
                                );
                            }
                        }
                    }
                }
                else if (entityType === 'classes_sections') {
                    const className = (row.class_name || row.standard || '').trim();
                    const section = (row.section || '').trim();
                    const medium = (row.medium || 'English').trim();
                    const stream = (row.stream || '').trim();
                    const academicYear = (row.academic_year || '').trim();
                    const capacity = parseInt(row.capacity || row.max_students || 40, 10);

                    const existingClassRows = await tx.query(
                        "SELECT id FROM classes WHERE school_id = ? AND LOWER(class_name) = LOWER(?) AND LOWER(section) = LOWER(?) AND LOWER(COALESCE(medium, 'english')) = LOWER(?) AND LOWER(COALESCE(stream, '')) = LOWER(?) LIMIT 1",
                        [schoolId, className, section, medium, stream]
                    );

                    if (existingClassRows.length > 0) {
                        await tx.query(
                            "UPDATE classes SET max_students = ?, academic_year = COALESCE(?, academic_year) WHERE id = ? AND school_id = ?",
                            [capacity, academicYear || null, existingClassRows[0].id, schoolId]
                        );
                    } else {
                        await tx.query(
                            "INSERT INTO classes (school_id, class_name, section, stream, medium, academic_year, max_students) VALUES (?, ?, ?, ?, ?, ?, ?)",
                            [schoolId, className, section, stream || null, medium, academicYear || null, capacity]
                        );
                    }
                }
                else if (entityType === 'subjects') {
                    const subjectName = (row.subject_name || row.name || '').trim();
                    const subjectCode = (row.subject_code || row.code || '').trim();
                    const subjectType = (row.subject_type || 'Theory').trim();
                    const className = (row.class_name || '').trim();
                    const section = (row.section || '').trim();
                    const medium = (row.medium || 'English').trim();
                    const maxMarks = parseFloat(row.max_marks || 100);
                    const passMarks = parseFloat(row.pass_marks || 33);

                    const existingSubRows = await tx.query(
                        "SELECT id FROM subjects WHERE school_id = ? AND (LOWER(subject_name) = LOWER(?) OR (code IS NOT NULL AND LOWER(code) = LOWER(?))) LIMIT 1",
                        [schoolId, subjectName, subjectCode || subjectName]
                    );

                    let subjectId;
                    if (existingSubRows.length > 0) {
                        subjectId = existingSubRows[0].id;
                        await tx.query(
                            "UPDATE subjects SET subject_name = ?, code = ?, subject_code = ?, subject_type = ?, max_marks = ?, pass_marks = ?, status = 'active' WHERE id = ? AND school_id = ?",
                            [subjectName, subjectCode || null, subjectCode || '', subjectType, maxMarks, passMarks, subjectId, schoolId]
                        );
                    } else {
                        const subRes = await tx.query(
                            "INSERT INTO subjects (school_id, subject_name, code, subject_code, subject_type, max_marks, pass_marks, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')",
                            [schoolId, subjectName, subjectCode || null, subjectCode || '', subjectType, maxMarks, passMarks]
                        );
                        subjectId = subRes.insertId;
                    }

                    if (className && section) {
                        const targetClassId = resolveClassId(cache, className, section, medium);
                        if (targetClassId) {
                            const existingCs = await tx.query(
                                "SELECT id FROM class_subjects WHERE school_id = ? AND class_id = ? AND subject_id = ? LIMIT 1",
                                [schoolId, targetClassId, subjectId]
                            );
                            if (existingCs.length > 0) {
                                await tx.query("UPDATE class_subjects SET status = 'active' WHERE id = ?", [existingCs[0].id]);
                            } else {
                                await tx.query(
                                    "INSERT INTO class_subjects (school_id, class_id, subject_id, status) VALUES (?, ?, ?, 'active')",
                                    [schoolId, targetClassId, subjectId]
                                );
                            }
                        }
                    }
                }
                else if (entityType === 'student_class_allocation') {
                    const studentAdmNo = (row.student_admission_no || row.student_id || '').toString().trim();
                    const className = (row.class_name || row.standard || '').trim();
                    const section = (row.section || '').trim();
                    const medium = (row.medium || 'English').trim();
                    const stream = (row.stream || '').trim();
                    const rollNo = (row.roll_no || '').toString().trim();

                    const targetClassId = resolveClassId(cache, className, section, medium, stream);
                    const studentRows = await tx.query(
                        "SELECT id FROM students WHERE (LOWER(admission_no) = LOWER(?) OR id = ?) AND school_id = ? AND deleted_at IS NULL LIMIT 1",
                        [studentAdmNo, parseInt(studentAdmNo) || 0, schoolId]
                    );

                    if (studentRows.length > 0 && targetClassId) {
                        const studentId = studentRows[0].id;
                        await tx.query(
                            "UPDATE students SET class_id = ?, roll_no = ?, status = 'active', updated_at = NOW() WHERE id = ? AND school_id = ?",
                            [targetClassId, rollNo || null, studentId, schoolId]
                        );
                        if (className) affectedClasses.add(className);
                    }
                }
                else if (entityType === 'teacher_subject_assignment') {
                    const teacherEmail = (row.teacher_email || row.teacher_id || row.email || '').toString().trim();
                    const subjectName = (row.subject_name || row.subject_code || '').trim();
                    const className = (row.class_name || row.standard || '').trim();
                    const section = (row.section || '').trim();
                    const medium = (row.medium || 'English').trim();
                    const stream = (row.stream || '').trim();
                    const academicYear = (row.academic_year || '').trim();

                    const teacherRows = await tx.query(
                        "SELECT t.id as teacher_id FROM teachers t JOIN users u ON t.user_id = u.id WHERE (LOWER(u.email) = LOWER(?) OR t.id = ?) AND t.school_id = ? LIMIT 1",
                        [teacherEmail.toLowerCase(), parseInt(teacherEmail) || 0, schoolId]
                    );

                    const subjectRows = await tx.query(
                        "SELECT id FROM subjects WHERE school_id = ? AND (LOWER(subject_name) = LOWER(?) OR LOWER(code) = LOWER(?)) LIMIT 1",
                        [schoolId, subjectName.toLowerCase(), subjectName.toLowerCase()]
                    );

                    const targetClassId = resolveClassId(cache, className, section, medium, stream);

                    if (teacherRows.length > 0 && subjectRows.length > 0 && targetClassId) {
                        const teacherId = teacherRows[0].teacher_id;
                        const subjectId = subjectRows[0].id;

                        const existingAssign = await tx.query(
                            "SELECT id FROM teacher_class_assign WHERE school_id = ? AND teacher_id = ? AND class_id = ? AND subject_id = ? LIMIT 1",
                            [schoolId, teacherId, targetClassId, subjectId]
                        );

                        if (existingAssign.length > 0) {
                            await tx.query("UPDATE teacher_class_assign SET status = 'active' WHERE id = ?", [existingAssign[0].id]);
                        } else {
                            await tx.query(
                                "INSERT INTO teacher_class_assign (school_id, teacher_id, class_id, subject_id, medium, academic_year, status) VALUES (?, ?, ?, ?, ?, ?, 'active')",
                                [schoolId, teacherId, targetClassId, subjectId, medium, academicYear || null]
                            );
                        }

                        const existingCs = await tx.query(
                            "SELECT id FROM class_subjects WHERE school_id = ? AND class_id = ? AND subject_id = ? LIMIT 1",
                            [schoolId, targetClassId, subjectId]
                        );
                        if (existingCs.length > 0) {
                            await tx.query("UPDATE class_subjects SET teacher_id = ?, status = 'active' WHERE id = ?", [teacherId, existingCs[0].id]);
                        } else {
                            await tx.query(
                                "INSERT INTO class_subjects (school_id, class_id, subject_id, teacher_id, status) VALUES (?, ?, ?, ?, 'active')",
                                [schoolId, targetClassId, subjectId, teacherId]
                            );
                        }
                    }
                }
                else if (entityType === 'timetable') {
                    const className = (row.class_name || row.standard || '').trim();
                    const section = (row.section || '').trim();
                    const medium = (row.medium || 'English').trim();
                    const stream = (row.stream || '').trim();
                    const day = (row.day || row.day_of_week || '').trim();
                    const periodNum = (row.period_number || row.period_slot_id || '').toString().trim();
                    const subjectName = (row.subject_name || row.subject_id || '').trim();
                    const teacherEmail = (row.teacher_email || row.teacher_id || '').toString().trim();
                    const room = (row.room || row.room_number || '').trim();

                    const targetClassId = resolveClassId(cache, className, section, medium, stream);
                    const subjectRows = await tx.query(
                        "SELECT id FROM subjects WHERE school_id = ? AND (LOWER(subject_name) = LOWER(?) OR LOWER(code) = LOWER(?)) LIMIT 1",
                        [schoolId, subjectName.toLowerCase(), subjectName.toLowerCase()]
                    );
                    const teacherRows = await tx.query(
                        "SELECT t.id as teacher_id FROM teachers t JOIN users u ON t.user_id = u.id WHERE (LOWER(u.email) = LOWER(?) OR t.id = ?) AND t.school_id = ? LIMIT 1",
                        [teacherEmail.toLowerCase(), parseInt(teacherEmail) || 0, schoolId]
                    );

                    const slotRows = await tx.query(
                        "SELECT id FROM period_slots WHERE school_id = ? AND (period_number = ? OR LOWER(label) = LOWER(?)) LIMIT 1",
                        [schoolId, parseInt(periodNum) || 0, periodNum.toLowerCase()]
                    );

                    let periodSlotId = slotRows[0]?.id || null;
                    if (!periodSlotId) {
                        const fallbackSlot = await tx.query(
                            "INSERT INTO period_slots (school_id, period_number, label, start_time, end_time, slot_type, status) VALUES (?, ?, ?, '09:00:00', '09:45:00', 'lecture', 'active')",
                            [schoolId, parseInt(periodNum) || 1, `Period ${periodNum}`]
                        );
                        periodSlotId = fallbackSlot.insertId;
                    }

                    if (targetClassId && subjectRows.length > 0 && teacherRows.length > 0 && periodSlotId) {
                        const subjectId = subjectRows[0].id;
                        const teacherId = teacherRows[0].teacher_id;
                        const normDay = day.toLowerCase();

                        let roomId = null;
                        if (room) {
                            const roomRows = await tx.query(
                                "SELECT id FROM rooms WHERE school_id = ? AND (LOWER(room_number) = LOWER(?) OR LOWER(name) = LOWER(?)) LIMIT 1",
                                [schoolId, room.toLowerCase(), room.toLowerCase()]
                            ).catch(() => []);
                            if (roomRows.length > 0) roomId = roomRows[0].id;
                        }

                        const existingTt = await tx.query(
                            "SELECT id FROM timetables WHERE school_id = ? AND class_id = ? AND LOWER(day_of_week) = ? AND period_slot_id = ? LIMIT 1",
                            [schoolId, targetClassId, normDay, periodSlotId]
                        );

                        if (existingTt.length > 0) {
                            await tx.query(
                                "UPDATE timetables SET subject_id = ?, teacher_id = ?, room_id = COALESCE(?, room_id), updated_by = ?, updated_at = NOW() WHERE id = ?",
                                [subjectId, teacherId, roomId, userId, existingTt[0].id]
                            );
                        } else {
                            await tx.query(
                                "INSERT INTO timetables (school_id, class_id, period_slot_id, day_of_week, subject_id, teacher_id, room_id, entry_type, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, 'lecture', ?)",
                                [schoolId, targetClassId, periodSlotId, normDay, subjectId, teacherId, roomId, userId]
                            );
                        }
                    }
                };
                successCount++;
            };
            if ((entityType === 'students' || entityType === 'student_class_allocation') && affectedClasses.size > 0) {
                const { recomputePortalAccessForClass } = require('./portalController');
                for (const className of affectedClasses) {
                    await recomputePortalAccessForClass(schoolId, className, tx);
                };
            };
        });

        const finalStatus = errors.length > 0 ? 'partial' : 'completed';
        await importLogModel.createLog({
            school_id: schoolId,
            imported_by: userId,
            user_role: userRole,
            entity_type: entityType,
            file_name: filename,
            file_path: relativeFilePath,
            total_rows: rows.length,
            success_count: successCount,
            failed_count: errors.length,
            error_report_path: errorReportUrl,
            status: finalStatus
        });

        if (fs.existsSync(fullFilePath)) fs.unlinkSync(fullFilePath);
        return {
            success: true,
            total_rows: rows.length,
            processed_rows: successCount + errors.length,
            success_count: successCount,
            failed_count: errors.length,
            errors,
            error_report_url: errorReportUrl
        };
    } catch (dbError) {
        await importLogModel.createLog({
            school_id: schoolId,
            imported_by: userId,
            user_role: userRole,
            entity_type: entityType,
            file_name: filename,
            file_path: relativeFilePath,
            total_rows: rows.length,
            success_count: 0,
            failed_count: rows.length,
            error_report_path: errorReportUrl,
            status: 'failed'
        });

        if (fs.existsSync(fullFilePath)) fs.unlinkSync(fullFilePath);
        return {
            success: false,
            message: 'Database transaction failed during bulk operations.',
            error_code: 'DATABASE_ERROR',
            errors,
            error_report_url: errorReportUrl
        };
    };
};