const test = require("node:test");
const assert = require("node:assert/strict");

const {
    addCycleToDate,
    amountForPlan,
    calculateSubscriptionEndDate,
    normalizeBillingCycle,
    toSqlDate
} = require("../utils/subscriptionPeriods");

function replaceModule(modulePath, exports) {
    const resolved = require.resolve(modulePath);
    const previous = require.cache[resolved];
    require.cache[resolved] = {
        id: resolved,
        filename: resolved,
        loaded: true,
        exports
    };
    return () => {
        if (previous) require.cache[resolved] = previous;
        else delete require.cache[resolved];
    };
}

function fakePlanRequest(overrides = {}) {
    const flashes = [];
    return {
        req: {
            body: {
                name: "Trial",
                plan_key: "trial",
                monthly_price: "0",
                yearly_price: "0",
                max_students: "",
                max_teachers: "",
                max_classes: "",
                trial_days: "15",
                is_active: "on",
                ...overrides
            },
            params: { id: "44" },
            path: "/superadmin/plans",
            user: { id: 1, role: "super_admin" },
            flash: (type, message) => flashes.push({ type, message })
        },
        res: {
            redirectPath: null,
            redirect(path) { this.redirectPath = path; }
        },
        flashes
    };
}

function loadPlanController() {
    const calls = [];
    const database = {
        queryAsync: async (sql) => {
            calls.push({ kind: "query", sql, params: arguments[1] });
            if (/SELECT \* FROM plans WHERE id/.test(sql)) return [{ id: 44, plan_key: "trial" }];
            return [];
        },
        executeAsync: async (sql, params = []) => {
            calls.push({ kind: "execute", sql, params });
            if (/INSERT INTO plans/.test(sql)) return { insertId: 44, affectedRows: 1 };
            return { affectedRows: 1 };
        }
    };
    const restores = [
        replaceModule("../config/database", database),
        replaceModule("../utils/auditLogger", { logSchoolActivity: async () => {} }),
        replaceModule("../utils/planCache", {
            invalidatePlanCache: async () => {},
            invalidateSubscriptionCache: async () => {}
        })
    ];
    const controllerPath = require.resolve("../controllers/superAdmin/planController");
    delete require.cache[controllerPath];
    const controller = require(controllerPath);
    return {
        calls,
        controller,
        restore() {
            delete require.cache[controllerPath];
            restores.reverse().forEach((fn) => fn());
        }
    };
}

test("monthly and yearly subscriptions use calendar durations", () => {
    assert.equal(normalizeBillingCycle("monthly"), "monthly");
    assert.equal(normalizeBillingCycle("yearly"), "yearly");
    assert.equal(normalizeBillingCycle("weekly"), null);
    assert.equal(toSqlDate(addCycleToDate(new Date("2025-01-31T00:00:00Z"), "monthly")), "2025-02-28");
    assert.equal(toSqlDate(addCycleToDate(new Date("2024-02-29T00:00:00Z"), "yearly")), "2025-02-28");
    assert.equal(toSqlDate(calculateSubscriptionEndDate(new Date("2026-07-01T00:00:00Z"), "monthly")), "2026-08-01");
    assert.equal(toSqlDate(calculateSubscriptionEndDate(new Date("2026-07-01T00:00:00Z"), "yearly")), "2027-07-01");
    assert.equal(amountForPlan({ monthly_price: "999", yearly_price: "9999" }, "monthly"), 999);
    assert.equal(amountForPlan({ monthly_price: "999", yearly_price: "9999" }, "yearly"), 9999);
});

test("Trial plan creation always stores 7 days and all features", async () => {
    const harness = loadPlanController();
    try {
        const { req, res } = fakePlanRequest({ trial_days: "15" });
        await harness.controller.create(req, res);
        const insert = harness.calls.find((call) => call.kind === "execute" && /INSERT INTO plans/.test(call.sql));
        assert.ok(insert, "plan INSERT should execute");
        assert.equal(insert.params[12], 7);
        const features = JSON.parse(insert.params[11]);
        assert.equal(features.admissions, true);
        assert.equal(Object.values(features).every(Boolean), true);
        assert.equal(res.redirectPath, "/superadmin/plans");
    } finally {
        harness.restore();
    }
});

test("Trial plan update stores 7 days while paid plans require zero", async () => {
    const harness = loadPlanController();
    try {
        const trial = fakePlanRequest({ trial_days: "0" });
        await harness.controller.update(trial.req, trial.res);
        const update = harness.calls.find((call) => call.kind === "execute" && /UPDATE plans SET/.test(call.sql));
        assert.ok(update, "plan UPDATE should execute");
        assert.equal(update.params[12], 7);

        assert.equal(harness.controller._test.resolveTrialDays("basic", "Basic", "0"), 0);
        assert.throws(
            () => harness.controller._test.resolveTrialDays("basic", "Basic", "7"),
            /Paid plans must use 0 trial days/
        );
        assert.throws(
            () => harness.controller._test.resolveTrialDays("trial", "Trial", "abc"),
            /non-negative whole number/
        );
    } finally {
        harness.restore();
    }
});

function loadSubscriptionService({ school, historyRows = [] }) {
    const writes = [];
    const db = {
        queryAsync: async (sql) => {
            if (/FROM subscriptions sub/.test(sql)) return historyRows;
            if (/SELECT id FROM subscriptions/.test(sql)) return [];
            return [];
        },
        executeAsync: async (sql, params) => {
            writes.push({ sql, params });
            return { affectedRows: 1 };
        },
        query: async (sql) => {
            if (/SELECT \* FROM schools/.test(sql)) return [[school], []];
            if (/SELECT \* FROM plans/.test(sql)) return [[{ id: 1, plan_key: "trial", features: "{}" }], []];
            if (/subscription_plan_features/.test(sql)) return [[], []];
            return [[], []];
        }
    };
    const restores = [
        replaceModule("../config/database", db),
        replaceModule("../services/notificationService", { createAndSend: async () => {} })
    ];
    const servicePath = require.resolve("../services/subscriptionService");
    delete require.cache[servicePath];
    const service = require(servicePath);
    return {
        service,
        writes,
        restore() {
            delete require.cache[servicePath];
            restores.reverse().forEach((fn) => fn());
        }
    };
}

test("Trial usage cannot be reset by changing plan or status fields", async () => {
    const datedSchool = { id: 9, trial_started_at: "2026-01-01", trial_used: 0, is_trial_used: 0 };
    const harness = loadSubscriptionService({ school: datedSchool });
    try {
        assert.equal(harness.service.hasSchoolUsedTrial(datedSchool), true);
        assert.equal(await harness.service.hasSchoolEverUsedTrial(9, { id: 9 }), false);
    } finally {
        harness.restore();
    }

    const historyHarness = loadSubscriptionService({ school: { id: 9 }, historyRows: [{ id: 1 }] });
    try {
        assert.equal(await historyHarness.service.hasSchoolEverUsedTrial(9, { id: 9 }), true);
    } finally {
        historyHarness.restore();
    }
});

test("active Trial grants admissions and expired Trial locks non-dashboard features", async () => {
    const activeHarness = loadSubscriptionService({
        school: {
            id: 7,
            status: "trial",
            subscription_status: "trial",
            current_plan_id: 1,
            trial_used: 1,
            trial_started_at: new Date(Date.now() - 86400000),
            trial_ends_at: new Date(Date.now() + 3 * 86400000)
        }
    });
    try {
        const state = await activeHarness.service.getSubscriptionState(7);
        assert.equal(state.isTrialActive, true);
        assert.equal(state.hasFeature("admissions"), true);
    } finally {
        activeHarness.restore();
    }

    const expiredHarness = loadSubscriptionService({
        school: {
            id: 8,
            status: "trial",
            subscription_status: "trial",
            current_plan_id: 1,
            trial_used: 1,
            trial_started_at: new Date(Date.now() - 10 * 86400000),
            trial_ends_at: new Date(Date.now() - 86400000)
        }
    });
    try {
        const state = await expiredHarness.service.getSubscriptionState(8);
        assert.equal(state.subscriptionLocked, true);
        assert.equal(state.hasFeature("dashboard"), true);
        assert.equal(state.hasFeature("admissions"), false);
        assert.ok(expiredHarness.writes.some((write) => /UPDATE schools/.test(write.sql)));
    } finally {
        expiredHarness.restore();
    }
});
